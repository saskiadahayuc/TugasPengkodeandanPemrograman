<?php
header('Content-Type: application/json');
include 'config.php';

$stmt = $pdo->query("SELECT * FROM suppliers ORDER BY supplier_id");
$suppliers = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($suppliers);
?>