<?php
header('Content-Type: application/json');
include 'config.php';

$id = $_POST['id'];
$item_name = $_POST['item_name'];
$category_id = $_POST['category_id'];
$supplier_id = $_POST['supplier_id'];
$quantity = $_POST['quantity'];
$price = $_POST['price'];

$stmt = $pdo->prepare("UPDATE items SET item_name = ?, category_id = ?, supplier_id = ?, quantity = ?, price = ? WHERE item_id = ?");
$success = $stmt->execute([$item_name, $category_id, $supplier_id, $quantity, $price, $id]);

echo json_encode(['success' => $success]);
?>