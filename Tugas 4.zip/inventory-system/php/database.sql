-- Membuat database jika belum ada
CREATE DATABASE IF NOT EXISTS inventory_system;
USE inventory_system;

-- Tabel Kategori
CREATE TABLE IF NOT EXISTS categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(50) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel Supplier
CREATE TABLE IF NOT EXISTS suppliers (
    supplier_id INT AUTO_INCREMENT PRIMARY KEY,
    supplier_name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(50),
    phone VARCHAR(15),
    email VARCHAR(100),
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel Barang
CREATE TABLE IF NOT EXISTS items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    item_name VARCHAR(100) NOT NULL,
    category_id INT NOT NULL,
    supplier_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 0,
    price DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE RESTRICT,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id) ON DELETE RESTRICT
);

-- Tabel Transaksi Masuk (Pembelian)
CREATE TABLE IF NOT EXISTS incoming_transactions (
    incoming_id INT AUTO_INCREMENT PRIMARY KEY,
    item_id INT NOT NULL,
    supplier_id INT NOT NULL,
    quantity INT NOT NULL,
    purchase_price DECIMAL(10,2) NOT NULL,
    transaction_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_id) REFERENCES items(item_id) ON DELETE RESTRICT,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id) ON DELETE RESTRICT
);

-- Tabel Transaksi Keluar (Penjualan atau Pengeluaran)
CREATE TABLE IF NOT EXISTS outgoing_transactions (
    outgoing_id INT AUTO_INCREMENT PRIMARY KEY,
    item_id INT NOT NULL,
    quantity INT NOT NULL,
    selling_price DECIMAL(10,2) NOT NULL,
    transaction_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_id) REFERENCES items(item_id) ON DELETE RESTRICT
);

-- Insert Data Dummy ke Tabel Kategori
INSERT INTO categories (category_name, description) VALUES
('Elektronik', 'Barang-barang elektronik seperti laptop dan gadget'),
('Peralatan Kantor', 'Peralatan untuk kebutuhan kantor'),
('Makanan', 'Makanan dan minuman ringan');

-- Insert Data Dummy ke Tabel Supplier
INSERT INTO suppliers (supplier_name, contact_person, phone, email, address) VALUES
('PT. Teknologi Maju', 'Budi Santoso', '081234567890', 'budi@teknologimaju.com', 'Jakarta'),
('CV. Sumber Rezeki', 'Siti Aisyah', '082345678901', 'siti@sumberrezeki.com', 'Bandung'),
('UD. Makmur Jaya', 'Agus Wijaya', '083456789012', 'agus@makmurjaya.com', 'Surabaya');

-- Insert Data Dummy ke Tabel Barang
INSERT INTO items (item_name, category_id, supplier_id, quantity, price) VALUES
('Laptop ASUS', 1, 1, 10, 15000.00),
('Mouse Logitech', 1, 2, 50, 150.00),
('Kertas A4', 2, 3, 100, 50.00),
('Snack Chiki', 3, 2, 200, 10.00);

-- Insert Data Dummy ke Tabel Transaksi Masuk
INSERT INTO incoming_transactions (item_id, supplier_id, quantity, purchase_price, transaction_date) VALUES
(1, 1, 5, 14000.00, '2025-03-01'),
(2, 2, 20, 120.00, '2025-03-02'),
(3, 3, 50, 45.00, '2025-03-03');

-- Insert Data Dummy ke Tabel Transaksi Keluar
INSERT INTO outgoing_transactions (item_id, quantity, selling_price, transaction_date) VALUES
(1, 2, 16000.00, '2025-03-05'),
(2, 10, 200.00, '2025-03-06'),
(4, 50, 15.00, '2025-03-07');

-- Menampilkan data untuk verifikasi
SELECT * FROM categories;
SELECT * FROM suppliers;
SELECT * FROM items;
SELECT * FROM incoming_transactions;
SELECT * FROM outgoing_transactions;