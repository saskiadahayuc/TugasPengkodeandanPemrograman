<?php
header('Content-Type: application/json');
include 'config.php';

$stmt = $pdo->query("
    SELECT i.*, c.category_name, s.supplier_name 
    FROM items i
    JOIN categories c ON i.category_id = c.category_id
    JOIN suppliers s ON i.supplier_id = s.supplier_id
    ORDER BY i.item_id
");
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($items);
?>