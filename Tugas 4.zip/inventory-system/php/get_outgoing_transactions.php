<?php
header('Content-Type: application/json');
include 'config.php';

$stmt = $pdo->query("
    SELECT ot.*, i.item_name 
    FROM outgoing_transactions ot
    JOIN items i ON ot.item_id = i.item_id
    ORDER BY ot.outgoing_id
");
$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($transactions);
?>