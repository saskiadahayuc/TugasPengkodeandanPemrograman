<?php
header('Content-Type: application/json');
include 'config.php';

$stmt = $pdo->query("
    SELECT it.*, i.item_name, s.supplier_name 
    FROM incoming_transactions it
    JOIN items i ON it.item_id = i.item_id
    JOIN suppliers s ON it.supplier_id = s.supplier_id
    ORDER BY it.incoming_id
");
$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($transactions);
?>