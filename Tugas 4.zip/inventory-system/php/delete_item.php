<?php
header('Content-Type: application/json');
include 'config.php';

$id = $_POST['id'];
$stmt = $pdo->prepare("DELETE FROM items WHERE item_id = ?");
$success = $stmt->execute([$id]);

echo json_encode(['success' => $success]);
?>