<?php
header('Content-Type: application/json');
include 'config.php';

$item_name = $_POST['item_name'];
$category_id = $_POST['category_id'];
$supplier_id = $_POST['supplier_id'];
$quantity = $_POST['quantity'];
$price = $_POST['price'];

$stmt = $pdo->prepare("INSERT INTO items (item_name, category_id, supplier_id, quantity, price) VALUES (?, ?, ?, ?, ?)");
$success = $stmt->execute([$item_name, $category_id, $supplier_id, $quantity, $price]);

echo json_encode(['success' => $success]);
?>