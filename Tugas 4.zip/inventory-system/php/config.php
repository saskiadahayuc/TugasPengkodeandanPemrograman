<?php
$host = 'localhost';
$dbname = 'inventory_system'; // Sesuaikan dengan nama database
$username = 'root'; // Username MySQL (default XAMPP adalah 'root')
$password = ''; // Password MySQL (default XAMPP adalah kosong)

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>