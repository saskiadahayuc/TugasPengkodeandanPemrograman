document.addEventListener('DOMContentLoaded', () => {
    loadCategories();
    loadSuppliers();
    loadItems();
    loadIncomingTransactions();
    loadOutgoingTransactions();

    // Isi dropdown kategori
    fetch('php/get_categories.php')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            const categorySelect = document.getElementById('category_id');
            if (data.length === 0) {
                console.warn('No categories found in the database.');
                categorySelect.innerHTML = '<option value="">No categories available</option>';
            } else {
                categorySelect.innerHTML = '<option value="">Select Category</option>';
                data.forEach(category => {
                    const option = document.createElement('option');
                    option.value = category.category_id;
                    option.textContent = category.category_name;
                    categorySelect.appendChild(option);
                });
            }
        })
        .catch(error => {
            console.error('Error loading categories for dropdown:', error);
            const categorySelect = document.getElementById('category_id');
            categorySelect.innerHTML = '<option value="">Error loading categories</option>';
        });

    // Isi dropdown supplier
    fetch('php/get_suppliers.php')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            const supplierSelect = document.getElementById('supplier_id');
            if (data.length === 0) {
                console.warn('No suppliers found in the database.');
                supplierSelect.innerHTML = '<option value="">No suppliers available</option>';
            } else {
                supplierSelect.innerHTML = '<option value="">Select Supplier</option>';
                data.forEach(supplier => {
                    const option = document.createElement('option');
                    option.value = supplier.supplier_id;
                    option.textContent = supplier.supplier_name;
                    supplierSelect.appendChild(option);
                });
            }
        })
        .catch(error => {
            console.error('Error loading suppliers for dropdown:', error);
            const supplierSelect = document.getElementById('supplier_id');
            supplierSelect.innerHTML = '<option value="">Error loading suppliers</option>';
        });

    // Form submission
    document.getElementById('itemForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const item_name = document.getElementById('item_name').value;
        const category_id = document.getElementById('category_id').value;
        const supplier_id = document.getElementById('supplier_id').value;
        const quantity = document.getElementById('quantity').value;
        const price = document.getElementById('price').value;

        if (!category_id || !supplier_id) {
            alert('Please select a category and supplier.');
            return;
        }

        fetch('php/add_item.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `item_name=${encodeURIComponent(item_name)}&category_id=${category_id}&supplier_id=${supplier_id}&quantity=${quantity}&price=${price}`
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                loadItems();
                this.reset();
                alert('Item added successfully!');
            } else {
                alert('Failed to add item.');
            }
        })
        .catch(error => console.error('Error adding item:', error));
    });
});

// Fungsi lain (loadCategories, loadSuppliers, dll.) tetap sama seperti sebelumnya
function loadCategories() {
    fetch('php/get_categories.php')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            const categoryList = document.getElementById('categoryList');
            categoryList.innerHTML = '';
            data.forEach(category => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${category.category_id}</td>
                    <td>${category.category_name}</td>
                    <td>${category.description || '-'}</td>
                `;
                categoryList.appendChild(tr);
            });
        })
        .catch(error => console.error('Error loading categories:', error));
}

function loadSuppliers() {
    fetch('php/get_suppliers.php')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            const supplierList = document.getElementById('supplierList');
            supplierList.innerHTML = '';
            data.forEach(supplier => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${supplier.supplier_id}</td>
                    <td>${supplier.supplier_name}</td>
                    <td>${supplier.contact_person || '-'}</td>
                    <td>${supplier.phone || '-'}</td>
                    <td>${supplier.email || '-'}</td>
                    <td>${supplier.address || '-'}</td>
                `;
                supplierList.appendChild(tr);
            });
        })
        .catch(error => console.error('Error loading suppliers:', error));
}

function loadItems() {
    fetch('php/get_items.php')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            const itemList = document.getElementById('itemList');
            itemList.innerHTML = '';
            data.forEach(item => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${item.item_id}</td>
                    <td>${item.item_name}</td>
                    <td>${item.category_name}</td>
                    <td>${item.supplier_name}</td>
                    <td>${item.quantity}</td>
                    <td>$${item.price.toFixed(2)}</td>
                    <td>
                        <button class="edit-btn" onclick="editItem(${item.item_id})">Edit</button>
                        <button class="delete-btn" onclick="deleteItem(${item.item_id})">Delete</button>
                    </td>
                `;
                itemList.appendChild(tr);
            });
        })
        .catch(error => console.error('Error loading items:', error));
}

function loadIncomingTransactions() {
    fetch('php/get_incoming_transactions.php')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            const incomingList = document.getElementById('incomingList');
            incomingList.innerHTML = '';
            data.forEach(transaction => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${transaction.incoming_id}</td>
                    <td>${transaction.item_name}</td>
                    <td>${transaction.supplier_name}</td>
                    <td>${transaction.quantity}</td>
                    <td>$${transaction.purchase_price.toFixed(2)}</td>
                    <td>${transaction.transaction_date}</td>
                `;
                incomingList.appendChild(tr);
            });
        })
        .catch(error => console.error('Error loading incoming transactions:', error));
}

function loadOutgoingTransactions() {
    fetch('php/get_outgoing_transactions.php')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            const outgoingList = document.getElementById('outgoingList');
            outgoingList.innerHTML = '';
            data.forEach(transaction => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${transaction.outgoing_id}</td>
                    <td>${transaction.item_name}</td>
                    <td>${transaction.quantity}</td>
                    <td>$${transaction.selling_price.toFixed(2)}</td>
                    <td>${transaction.transaction_date}</td>
                `;
                outgoingList.appendChild(tr);
            });
        })
        .catch(error => console.error('Error loading outgoing transactions:', error));
}

function deleteItem(id) {
    if (confirm('Are you sure you want to delete this item?')) {
        fetch('php/delete_item.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `id=${id}`
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                loadItems();
                alert('Item deleted successfully!');
            }
        })
        .catch(error => console.error('Error deleting item:', error));
    }
}

function editItem(id) {
    alert('Edit functionality can be implemented as needed');
}